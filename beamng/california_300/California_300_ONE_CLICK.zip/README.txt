California 300 — One Click Install
=================================

1) Extract this ZIP anywhere (Desktop is fine)
2) Open the extracted folder
3) Double-click INSTALL_CALIFORNIA_300.bat
4) If Windows warns: More info -> Run anyway
5) Open BeamNG -> Freeroam -> California 300

Includes:
- California 300 level
- CA300 Race Ready course DecalRoad
- Pit row
- Start/Finish spawn
- Desert materials
- Heightmap import preset

This installer only copies local files into BeamNG.
It does not download anything.
