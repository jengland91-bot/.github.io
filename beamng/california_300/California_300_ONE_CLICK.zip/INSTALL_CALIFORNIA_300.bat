@echo off
setlocal EnableExtensions
title Install California 300
echo ========================================
echo  California 300 - One Click Install
echo ========================================
echo.
echo This copies the map + CA300 course into BeamNG.
echo No internet download. Local copy only.
echo.

set "SRC=%~dp0levels\california_300"
set "BEAM=%LOCALAPPDATA%\BeamNG\BeamNG.drive\current"
set "DEST=%BEAM%\levels\california_300"

if not exist "%SRC%\info.json" (
  echo ERROR: levels\california_300 missing next to this .bat
  echo Extract the whole ZIP first, then run INSTALL_CALIFORNIA_300.bat
  pause
  exit /b 1
)

if not exist "%BEAM%" (
  echo ERROR: BeamNG folder not found:
  echo   %BEAM%
  echo Open BeamNG once, close it, then run this again.
  pause
  exit /b 1
)

mkdir "%BEAM%\levels" 2>nul
echo Copying California 300 into:
echo   %DEST%
echo.
xcopy "%SRC%\*" "%DEST%\" /E /I /Y /Q
if errorlevel 1 (
  echo Copy failed.
  pause
  exit /b 1
)

echo.
echo DONE.
echo.
echo Next:
echo 1^) Open BeamNG
echo 2^) Freeroam -^> California 300
echo 3^) You should see the CA300 course road (ca300_race_ready^)
echo 4^) If terrain is missing/flat, F11 -^> Import Terrain
echo    Load preset: import\ca300_gpx_scale.preset.json
echo    Meters/pixel=4  MaxHeight=900
echo.
explorer "%DEST%"
pause
