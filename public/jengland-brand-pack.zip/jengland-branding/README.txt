J England streaming brand pack
==============================

Upload what you want. Nothing auto-loads to Twitch / Kick / YouTube.

01-avatar/
  avatar-800x800.png     -> Twitch, Kick, YouTube profile picture

02-twitch/
  twitch-banner-clean-1200x480.png  -> Twitch profile banner (Creator Dashboard > Brand)

03-kick/
  kick-banner-clean-1280x700.png    -> Kick channel banner

04-offline-meld/
  offline-screen-clean-1920x1080.png -> Twitch offline / Meld image layer
  starting-soon-1920x1080.svg        -> Meld STARTING scene
  brb-1920x1080.svg                  -> Meld BRB scene
  ending-soon-1920x1080.svg          -> Meld ENDING scene

05-panels/
  panel-*.svg -> Twitch / Kick about panels (optional)

STARTER BIO (same on Twitch + Kick):
-----------------------------------
Sim racing | games | IRL
Josh England — photographer & creator.
Links + gear → jenglandblog.netlify.app/links

Channels:
  https://www.twitch.tv/jengland91
  https://kick.com/jengland91
  https://www.youtube.com/@Joshengland91
